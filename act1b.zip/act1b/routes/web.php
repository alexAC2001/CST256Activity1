<?php
// Alexander Carrillo

// CST-256

// January 24, 2021

// I used source code from the following websites to complete this assignment:
// https://stackoverflow.com/questions/42505607/laravel-5-4-view-name-not-found
// https://www.php.net/manual/en/language.types.string.php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/hello', function () {
    return view('welcome');
});
Route::get('/helloworld', function () {
    return view('helloWorldtest');
});
Route::get('/test', 'TestController@test');
Route::get('/test2', 'TestController@test2');
